//This is where all the functions that deal with file IO will go
//hello
//hello2
//hello3