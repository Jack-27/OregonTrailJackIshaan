void init() {
//initializes game by doing the following steps
// Load in milestone array
// Load new party
// Ask for name of player
// Ask for names of companians
// Choose start date
//all give a little bit of story

}
int main() {
    while (mainParty.isOver() == true) {
        turn();
    }

}